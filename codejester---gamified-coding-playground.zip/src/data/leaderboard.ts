import { LeaderboardEntry } from '../types';

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  {
    id: 'user_1',
    rank: 1,
    username: 'SemicolonSlayer',
    avatar: '🥷',
    titleBadge: 'Semicolon Ninja',
    xp: 2850,
    level: 14,
    solvedPuzzles: 28,
    streakDays: 19,
    funnyBio: 'I debug in production while drinking double espresso.'
  },
  {
    id: 'user_2',
    rank: 2,
    username: 'StackOverflowVIP',
    avatar: '🧙‍♂️',
    titleBadge: 'Copy-Paste Wizard',
    xp: 2420,
    level: 12,
    solvedPuzzles: 24,
    streakDays: 14,
    funnyBio: 'Ctrl+C and Ctrl+V are my favorite keyboard keys.'
  },
  {
    id: 'user_3',
    rank: 3,
    username: 'ByteSizedCat',
    avatar: '🐱',
    titleBadge: 'Keyboard Walker',
    xp: 2100,
    level: 10,
    solvedPuzzles: 21,
    streakDays: 12,
    funnyBio: 'Meow meow console.log("feed me")'
  },
  {
    id: 'user_4',
    rank: 4,
    username: 'CoffeeToCode',
    avatar: '☕',
    titleBadge: 'Caffeine Engine',
    xp: 1850,
    level: 9,
    solvedPuzzles: 18,
    streakDays: 8,
    funnyBio: 'Turning cold brew coffee into hot JavaScript bugs.'
  },
  {
    id: 'user_5',
    rank: 5,
    username: 'RegExMastermind',
    avatar: '👾',
    titleBadge: 'Pattern Whisperer',
    xp: 1600,
    level: 8,
    solvedPuzzles: 16,
    streakDays: 6,
    funnyBio: 'I write regular expressions that scare alien civilizations.'
  },
  {
    id: 'user_6',
    rank: 6,
    username: 'SpaghettiChef',
    avatar: '🍝',
    titleBadge: 'Nested Loop Titan',
    xp: 1350,
    level: 6,
    solvedPuzzles: 13,
    streakDays: 4,
    funnyBio: 'My code has 12 nested if statements and I wear it like a badge of honor.'
  },
  {
    id: 'user_7',
    rank: 7,
    username: 'AsyncWaitGoal',
    avatar: '🏎️',
    titleBadge: 'Promise Racer',
    xp: 1100,
    level: 5,
    solvedPuzzles: 11,
    streakDays: 3,
    funnyBio: 'I resolve my promises faster than my morning alarm.'
  }
];
